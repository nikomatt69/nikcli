# nikcli brand kit

Generated 2026-07-25 from packages/mobile/assets/.

Every file inside this archive is a portable rasterization of the nikcli brand.
Filenames and content match the source files committed to `packages/mobile/assets/`.

## What's inside

- **wordmark-{dark,light}.png** — pixel wordmark, 632×206, transparent background
  - `wordmark.png` is the master (identical to `wordmark-dark.png`)
- **icon-{dark,light}.png** — 1024×1024 app icons (light + dark surfaces)
  - `icon.png` is the master (identical to `icon-dark.png`)
- **adaptive-icon-{,-light}.png** — 1024×1024 Android-adaptive layer (33% safe zone)
- **app-icon-mark-{,-light}.png** — 128×128 monograms for tab bars and docks
- **favicon-{,-light}.png** — 48×48 web favicons
- **splash-{dark,light}.png** — 1024×1024 launch screens
  - `splash.png` is the master (identical to `splash-dark.png`)

## How to use

Open the brand assets docs page for usage rules, theme pairing, and aspect ratios:

    /docs/brand

## Source of truth

These PNGs are mirrored from `packages/mobile/assets/`. Re-run the build
script whenever a source asset changes:

    bun run --cwd packages/web script/build-brandkit.ts
